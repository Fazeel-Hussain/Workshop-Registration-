﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_C_2
{
    class StudentOperations
    {
        public static void CreateStudent(string firstName, string lastName, object[] studArray)
        {

            // supposed to create a student
            Console.WriteLine("sreate student method called");
            string firstInit = firstName.Substring(0, 1);
            string lastInit = lastName.Substring(0, 1);
            string value = GenValueStub.generateValueStub();

            Student stu = new Student();
            stu.studentId = firstInit + lastInit + value; //creates student id
            stu.grade = 0;
            stu.firstName = firstName;
            stu.lastName = lastName;
            studArray[9] = stu;//initial grade is 0 so they go to the end untill the grade is updated
        }

        
    }
}
