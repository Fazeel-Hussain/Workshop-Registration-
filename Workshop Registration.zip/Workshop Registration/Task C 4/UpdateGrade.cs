﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_C_4
{
    public class UpdateGrade
    {
        //Update the grade of a student at a given index to a given new grade.
        //After updating the grade, you need to call the sort method.
        public static void updateGrade(object[] studArray, int grade, int studArrayIndex)
        {
            Console.WriteLine("update Grade Called!");
            Student stu = (Student)studArray.GetValue(studArrayIndex);
            stu.grade = grade;
            sortStub(studArray);
        }
        public static void sortStub(object[] studArray)
        {
            studArray[0] = studArray[9];
            studArray[9] = null;
        }



    }
}
