﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_C_4
{
    public class GenValue
    {
        private static Random randomNum = new Random();
        public static string generateValue()
        {
            string[] myNum = { "8", "7", "0", "2,", "6", "4", "4" };
            for (int i = myNum.Length - 1; i > 0; i--)
            {
                int j = randomNum.Next(i + 1);
                string temp = myNum[i];
                myNum[i] = myNum[j];
                myNum[j] = temp;

            }
          
            
            string stNum = "";

            for(int i =0;i< myNum.Length; i++)
            {
                stNum = stNum + myNum[i];
            }
            return stNum;
        }
    }
}
