﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_C_4
{
    class sortStub
    {
        public static void SortStub(object[] studArray)
        {
            studArray[0] = studArray[9];
            studArray[9] = null;
        }
    }
}
