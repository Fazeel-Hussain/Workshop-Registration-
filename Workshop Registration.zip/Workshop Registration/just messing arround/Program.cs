﻿using System;

namespace just_messing_arround
{
    public static class Program
    {
        private static Random randomNum = new Random();
        public static string[] doShuffle(string[] objects)
        {
            for(int i = objects.Length -1; i >0; i--)
            {
                int j = randomNum.Next(i + 1);
                string temp = objects[i];
                objects[i] = objects[j];
                objects[j] = temp;
                
            }

            return objects;
        }

        public static void sort(Student[] studArray)
        {

            Array.Sort(studArray);
            Array.Reverse(studArray);
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine(studArray[i].grade);
            }



        }

        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            // i want to shuffle a string
            int[] stNum = new int[7];
            stNum[0] = 8; stNum[1] = 7; stNum[2] = 0; stNum[3] = 2; stNum[4] = 6; stNum[5] = 4; stNum[6] = 4;

            string[] myNum = { "8", "7", "0", "2,", "6", "4", "4" };
            myNum = Program.doShuffle(myNum);
            for (int i =0; i < 7; i++)
            {
                Console.WriteLine(myNum[i]);
            }
            Student[] studArray = new Student[10];
            studArray[0] = new Student();
            studArray[0].grade = 25;

            studArray[1] = new Student();
            studArray[1].grade = 17;
            studArray[2] = new Student();
            studArray[2].grade = 95;

            sort(studArray);
            studArray = null;
        }
    }
}
