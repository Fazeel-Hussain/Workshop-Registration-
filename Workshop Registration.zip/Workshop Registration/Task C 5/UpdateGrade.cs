﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_C_5
{
    public class UpdateGrade
    {
        //Update the grade of a student at a given index to a given new grade.
        //After updating the grade, you need to call the sort method.
        public static void updateGrade(object[] studArray, int grade, int studArrayIndex)
        {
            Student stu = (Student)studArray.GetValue(studArrayIndex);
            stu.grade = grade;
            Sort.sort(studArray);
        }
       



    }
}
