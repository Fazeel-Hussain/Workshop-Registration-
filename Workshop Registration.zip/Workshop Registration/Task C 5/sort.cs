﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_C_5
{
    public class Sort
    {
        public static void sort(object[] studArray)
        {
            Console.WriteLine("sort called");
            Array.Sort(studArray); //sorts array in order frm lowest grade to highest
            Array.Reverse(studArray); //reverses the sorted array to get highest grade to lowest grade

        }
    }
}
