﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task_C_3
{
    public class Student : IComparable<Student>
    {
        //constructor with the attributes

        public string firstName, lastName;
        public string studentId; //id in format first initial, last initial, shuffled of my student id (8702644) 
        public int grade;
        public Student()
        {
            firstName = "john";
            lastName = "doe";
            studentId = "";
            grade = 75;
        }

        public Student(string first,string last, string id,int grade)
        {
            this.grade = grade;
            firstName = first;
            lastName = last;
            studentId = id;
        }
        public int CompareTo(Student other)
        {
            return grade.CompareTo(other.grade);
        }
    }
}
