﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_C_1
{
    class UpdateGradeStub
    {
        public static void updateGradeStub(object[] studArray, int studArrayIndex)
        {
            Student stu = (Student)studArray.GetValue(studArrayIndex);
            stu.grade = 55;
            studArray[studArrayIndex] = stu;
            sortStub.SortStub(studArray);
        }

    }
}
