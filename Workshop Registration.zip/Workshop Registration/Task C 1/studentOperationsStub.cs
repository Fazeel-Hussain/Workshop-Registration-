﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_C_1
{
    class studentOperationsStub
    {
        public static void createStudentStub( object[] studArray)
        {
            Student studObj = new Student();
            studObj.firstName = "faizel";
            studObj.lastName = "hussain"; 
            studObj.grade = 0;
            studObj.studentId = "FH" + GenValueStub.generateValueStub();
            studArray[9] = studObj;

        }
    }
}
