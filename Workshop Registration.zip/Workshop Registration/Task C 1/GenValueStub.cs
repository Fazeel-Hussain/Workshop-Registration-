﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_C_1
{
    class GenValueStub
    {
        public static string generateValueStub()
        {
            return "8702644";
        }
    }
}
