﻿using System;

namespace Task_C_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Workshop Manager!\n Please select one of the options bellow\n");
            object[] studentArray = new object[10];

            do
            {
                Console.WriteLine("1.) Add a New Student\n2.) Display Students\n3.) Clear Students\n4.) Update Student Grades\n5.) quit");
                //Student[] studentArray = new Student[10];


                //StudentOperations.CreateStudent("first", "last", studentArray);//these two lines will go in main
                string selctn = Console.ReadLine();
                if (selctn == "1")
                {
                    

                    studentOperationsStub.createStudentStub( studentArray);
                }

                else if (selctn == "2")
                {
                    foreach(Student stu in studentArray)
                    {
                       


                            if (stu != null)
                            {

                            Console.Write(stu.firstName);
                            Console.Write(stu.lastName);
                            Console.Write(stu.grade);
                            Console.WriteLine("\n");
                        }
                       
                        
                    }
                }

                else if (selctn == "3")
                {
                    studentArray = null;
                    Console.WriteLine("all students cleared");
                }

                else if (selctn == "4")
                {
                    Console.WriteLine("enter the student index value: ");
                    int indexValue = int.Parse(Console.ReadLine());

                    Console.WriteLine("enter the new grade: ");
                    int grade = int.Parse(Console.ReadLine());
                    
                    UpdateGradeStub.updateGradeStub(studentArray, indexValue);

                }
               
                else if (selctn == "5")
                {
                    break;
                }
                else
                {
                    Console.WriteLine("invalid entry. Please try again.");
                }

            } while (true);
        }
    }
}
