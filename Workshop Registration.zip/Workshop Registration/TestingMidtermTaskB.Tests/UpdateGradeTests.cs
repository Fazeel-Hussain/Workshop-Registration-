﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace TestingMidtermTaskB.Tests
{
    [TestClass]
    public class UpdateGradeTests
    {
        [TestMethod]
        public void UpdateGrade_Test1()
        {
            object[] workshop = new object[10];
            int index = 9;
            int grade = 55;

            Student stu = new Student();
            stu.firstName = "john";
            stu.lastName = "doe";
            stu.studentId = "jd8702644";
            stu.grade = 0;
            workshop[index] = stu;
            //Act
            UpdateGrade.updateGrade(workshop, grade, index);

            //Assert

            Assert.AreEqual(55, stu.grade);

        }

        [TestMethod]
        public void UpdateGrade_Test2()
        {
            object[] workshop = new object[10];
            int index = 9;
            int grade = 55;

            Student stu = new Student();
            stu.firstName = "john";
            stu.lastName = "doe";
            stu.studentId = "jd8702644";
            stu.grade = 0;
            workshop[index] = stu;
            //Act
            UpdateGrade.updateGrade(workshop, grade, index);

            //Assert

            Assert.AreNotEqual(0, stu.grade);

        }

    }
}
