using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestingMidtermTaskB;

namespace TestingMidtermTaskB.Tests
{
    [TestClass]
    public class StudentOperationsTest
    {
        [TestMethod]
        public void CreateStudent_I_0()
        {
            //Arrange
            object[] workshop = new object[10];
            string first = "john";
            string last = "doe";
            Student stu = new Student();
            //Act
            StudentOperations.CreateStudent(first,last, workshop);
            stu = (Student)workshop[9];
            
            //Assert

            Assert.AreEqual("jd8702644", stu.studentId);


        }

        [TestMethod]
        public void CreateStudent_john_doe_0()
        {
            //Arrange
            object[] workshop = new object[10];
            string first = "john";
            string last = "doe";
            Student stu = new Student();
            //Act
            StudentOperations.CreateStudent(first, last, workshop);
            stu = (Student)workshop[9];

            //Assert

            Assert.AreEqual(0, stu.grade);


        }


    }
}
