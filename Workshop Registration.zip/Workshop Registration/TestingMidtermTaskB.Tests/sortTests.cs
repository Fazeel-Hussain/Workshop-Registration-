﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestingMidtermTaskB;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestingMidtermTaskB.Tests
{
    [TestClass]
    public class sortTests
    {

        [TestMethod]
        public void sort_test1()
        {
            object[] initial = new object[3];
            Student stu1 = new Student();
            Student stu2 = new Student();
            Student stu3 = new Student();

            stu1.firstName = "joe";
            stu1.lastName = "man";
            stu1.studentId = "8702644";
            stu1.grade = 15;

            stu2.firstName = "naruto";
            stu2.lastName = "uchiha";
            stu2.studentId = "8702645";
            stu2.grade = 95;

            stu3.firstName = "sasuke";
            stu3.lastName = "uzaki";
            stu3.studentId = "8702646";
            stu3.grade = 38;

            initial[0] = stu1;
            initial[1] = stu2;
            initial[2] = stu3;

            object[] final = new object[3];
            Student Stu1 = new Student();
            Student Stu2 = new Student();
            Student Stu3 = new Student();

            Stu1 = stu2;
            Stu2 = stu3;
            Stu3 = stu1;
            final[0] = Stu1;
            final[1] = Stu2;
            final[2] = Stu3;

            Sort.sort(initial);

            CollectionAssert.AreEqual(final, initial);

        }
        [TestMethod]
        public void sort_test2()
        {
            object[] initial = new object[3];
            Student stu1 = new Student();
            Student stu2 = new Student();
            Student stu3 = new Student();

            stu1.firstName = "joe";
            stu1.lastName = "man";
            stu1.studentId = "8702644";
            stu1.grade = 26;

            stu2.firstName = "naruto";
            stu2.lastName = "uchiha";
            stu2.studentId = "8702645";
            stu2.grade = 99;

            stu3.firstName = "sasuke";
            stu3.lastName = "uzaki";
            stu3.studentId = "8702646";
            stu3.grade = 59;

            initial[0] = stu1;
            initial[1] = stu2;
            initial[2] = stu3;

            object[] final = new object[3];
            Student Stu1 = new Student();
            Student Stu2 = new Student();
            Student Stu3 = new Student();

            Stu1 = stu2;
            Stu2 = stu3;
            Stu3 = stu1;
            final[0] = Stu1;
            final[1] = Stu2;
            final[2] = Stu3;

            Sort.sort(initial);

            CollectionAssert.AreEqual(final, initial);

        }


    }
}
