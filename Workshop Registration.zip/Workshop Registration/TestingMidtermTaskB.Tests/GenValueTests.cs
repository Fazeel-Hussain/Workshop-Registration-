﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace TestingMidtermTaskB.Tests
{
    [TestClass]
    public class GenValueTests
    {
        [TestMethod]
        public void GenValue_test1()
        {
            //arrange
            string pseudo = "8702644";
            //act
            string result = GenValue.generateValue();
            //assert
            Assert.AreNotEqual(pseudo, result);

        }
        [TestMethod]
        public void GenValue_test2()
        {
            //arrange
            int length = 8;
            //act
            string result = GenValue.generateValue();
            // assert
            Assert.AreEqual(result.Length, length);
        }
    }
}
